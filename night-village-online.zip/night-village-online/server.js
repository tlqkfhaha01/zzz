const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.static("public"));

const rooms = new Map();
const code = () => Math.random().toString(36).slice(2,6).toUpperCase();
const pick = a => a[Math.floor(Math.random()*a.length)];
const alive = r => r.players.filter(p=>p.alive);
const mafias = r => alive(r).filter(p=>p.role==="mafia");
const town = r => alive(r).filter(p=>p.role!=="mafia");
const pub = r => ({
  code:r.code, hostId:r.hostId, status:r.status, phase:r.phase, round:r.round,
  settings:r.settings,
  players:r.players.map(p=>({id:p.id,name:p.name,isAI:p.isAI,alive:p.alive,connected:p.isAI||!!io.sockets.sockets.get(p.id)})),
  log:r.log.slice(-18), discussionEndsAt:r.discussionEndsAt||null
});
function sendRoom(r){
  for(const p of r.players) if(!p.isAI && io.sockets.sockets.get(p.id))
    io.to(p.id).emit("state",{room:pub(r),me:{id:p.id,name:p.name,role:p.role,roleInfo:roleInfo(p.role),mafia: p.role==="mafia"?mafias(r).map(x=>x.name):[]}});
}
function roleInfo(role){
 const info={mafia:["🔪 마피아","밤마다 시민 한 명을 제거합니다. 마피아끼리는 서로를 알고 있습니다."],
 citizen:["🧑‍🌾 시민","토론과 투표로 마피아를 찾아내세요."],
 doctor:["🩺 의사","밤마다 한 명을 선택해 공격으로부터 보호합니다."],
 detective:["🔎 경찰","밤마다 한 명을 조사해 마피아인지 확인합니다."]};
 return info[role]||info.citizen;
}
function log(r,msg){r.log.push(msg);if(r.log.length>40)r.log.shift()}
function endCheck(r){
 const m=mafias(r).length,t=town(r).length;
 if(m===0){r.status="ended";r.phase="ended";r.winner="citizen";log(r,"🎉 시민 팀 승리! 마피아를 모두 찾아냈습니다.");return true}
 if(m>=t){r.status="ended";r.phase="ended";r.winner="mafia";log(r,"🔪 마피아 팀 승리! 마피아가 마을을 장악했습니다.");return true}
 return false;
}
function createAI(r,n){
 const names=["모카","루나","두부","감자","초코","나비","구름","호두","라임","보리","밤톨","쿠키"];
 for(let i=0;i<n;i++){
  let name=names.find(x=>!r.players.some(p=>p.name===x))||"AI"+(i+1);
  r.players.push({id:"ai_"+crypto.randomBytes(4).toString("hex"),name,isAI:true,alive:true,role:"citizen",personality:pick(["논리적인","수다스러운","소심한","능청스러운"])});
 }
}
function assignRoles(r){
 const total=r.players.length, nM=total>=9?3:total>=6?2:1;
 let roles=Array(nM).fill("mafia");roles.push("doctor");
 if(total>=6)roles.push("detective");
 while(roles.length<total)roles.push("citizen");
 roles.sort(()=>Math.random()-.5);
 r.players.forEach((p,i)=>{p.role=roles[i];p.alive=true});
}
function startNight(r){
 r.phase="night";r.round++;r.night={mafia:null,doctor:null,detective:null,done:new Set()};
 log(r,`🌑 ${r.round}번째 밤이 찾아왔습니다.`);
 // AI actions happen automatically
 const living=alive(r), ai= living.filter(p=>p.isAI);
 const mafiaAI=ai.filter(p=>p.role==="mafia");
 if(mafiaAI.length){
  const targets=living.filter(p=>p.role!=="mafia");
  r.night.mafia=pick(targets)?.id||null;
 }
 const doc= living.find(p=>p.role==="doctor");
 if(doc?.isAI)r.night.doctor=pick(living.filter(p=>p.id!==doc.id))?.id||doc.id;
 const det=living.find(p=>p.role==="detective");
 if(det?.isAI){
  const targets=living.filter(p=>p.id!==det.id);
  const target=pick(targets);
  if(target)r.night.detectiveResult={playerId:det.id,target:target.name,isMafia:target.role==="mafia"};
 }
 // One human mafia action is enough; if any human mafia alive wait for one.
 maybeFinishNight(r);
}
function maybeFinishNight(r){
 if(r.phase!=="night")return;
 const required=[];
 if(alive(r).some(p=>p.role==="mafia"&&!p.isAI))required.push("mafia");
 if(alive(r).some(p=>p.role==="doctor"&&!p.isAI))required.push("doctor");
 if(alive(r).some(p=>p.role==="detective"&&!p.isAI))required.push("detective");
 if(required.every(k=>r.night.done.has(k)))finishNight(r);
}
function finishNight(r){
 if(r.phase!=="night")return;
 const target=r.night.mafia;
 if(target){
  const victim=r.players.find(p=>p.id===target);
  if(victim && r.night.doctor!==target){victim.alive=false;log(r,`🌙 밤 사이 ${victim.name}님이 탈락했습니다.`)}
  else log(r,"🌙 누군가 공격받았지만 의사의 치료로 살아났습니다.");
 }else log(r,"🌙 밤은 조용히 지나갔습니다.");
 for(const p of r.players.filter(x=>x.role==="detective"&&!x.isAI)){
  const result=r.night.detectiveResult;
  if(result?.playerId===p.id){
   const socket=io.sockets.sockets.get(p.id);
   socket?.emit("privateResult",{message:`🔎 조사 결과: ${result.target}님은 ${result.isMafia?"마피아입니다!":"마피아가 아닙니다."}`});
  }
 }
 if(endCheck(r)){sendRoom(r);return}
 r.phase="day";r.discussionEndsAt=Date.now()+60000;
 log(r,"☀️ 아침이 밝았습니다. 자유롭게 토론한 뒤 방장이 투표를 시작하세요.");
 sendRoom(r);
}
function aiVotes(r){
 const living=alive(r);
 for(const p of living.filter(x=>x.isAI)){
  const options=living.filter(x=>x.id!==p.id);
  if(!options.length){r.votes[p.id]=null;continue}
  // AI have imperfect information; a small difficulty-dependent bias toward mafia.
  const mafia=options.filter(x=>x.role==="mafia");
  const chance=r.settings.difficulty==="hard"?.62:r.settings.difficulty==="easy"?.25:.42;
  let chosen=Math.random()<chance&&mafia.length?pick(mafia):pick(options);
  r.votes[p.id]=chosen.id;
 }
}
function resolveVotes(r){
 aiVotes(r);
 const tally={};
 for(const id of Object.values(r.votes))if(id)tally[id]=(tally[id]||0)+1;
 const max=Math.max(0,...Object.values(tally));
 const leaders=Object.keys(tally).filter(id=>tally[id]===max);
 if(max===0||leaders.length!==1)log(r,"🗳️ 투표가 동점이 되어 아무도 탈락하지 않았습니다.");
 else{
  const out=r.players.find(p=>p.id===leaders[0]);out.alive=false;
  log(r,`🗳️ ${out.name}님이 투표로 탈락했습니다. 정체는 ${roleInfo(out.role)[0]}였습니다.`);
 }
 if(!endCheck(r))startNight(r);
 sendRoom(r);
}
io.on("connection",socket=>{
 socket.on("createRoom",({name,aiCount=0,difficulty="normal"},cb)=>{
  const roomCode=code();const player={id:socket.id,name:String(name||"플레이어").slice(0,16),isAI:false,alive:true,role:"citizen"};
  const r={code:roomCode,hostId:socket.id,status:"lobby",phase:"lobby",round:0,players:[player],settings:{aiCount:Math.max(0,Math.min(8,+aiCount||0)),difficulty},log:[],votes:{},night:null};
  rooms.set(roomCode,r);socket.join(roomCode);cb?.({ok:true,code:roomCode});sendRoom(r);
 });
 socket.on("joinRoom",({code:roomCode,name},cb)=>{
  const r=rooms.get(String(roomCode||"").toUpperCase());
  if(!r)return cb?.({ok:false,error:"방을 찾을 수 없습니다."});
  if(r.status!=="lobby")return cb?.({ok:false,error:"이미 게임이 시작된 방입니다."});
  if(r.players.filter(p=>!p.isAI).length>=12)return cb?.({ok:false,error:"방 인원이 가득 찼습니다."});
  const clean=String(name||"플레이어").trim().slice(0,16)||"플레이어";
  if(r.players.some(p=>p.name===clean))return cb?.({ok:false,error:"이미 사용 중인 이름입니다."});
  r.players.push({id:socket.id,name:clean,isAI:false,alive:true,role:"citizen"});
  socket.join(r.code);cb?.({ok:true,code:r.code});log(r,`${clean}님이 입장했습니다.`);sendRoom(r);
 });
 socket.on("addAI",({count=1},cb)=>{
  const r=[...rooms.values()].find(x=>x.hostId===socket.id);
  if(!r||r.status!=="lobby")return cb?.({ok:false,error:"대기실 방장만 사용할 수 있습니다."});
  const current=r.players.length, add=Math.min(Math.max(0,+count||0),12-current);
  createAI(r,add);r.settings.aiCount=r.players.filter(p=>p.isAI).length;sendRoom(r);cb?.({ok:true});
 });
 socket.on("startGame",(_,cb)=>{
  const r=[...rooms.values()].find(x=>x.hostId===socket.id);
  if(!r||r.status!=="lobby")return cb?.({ok:false,error:"게임을 시작할 수 없습니다."});
  if(r.players.length<5)return cb?.({ok:false,error:"AI를 포함해 최소 5명이 필요합니다."});
  if(r.players.length>12)return cb?.({ok:false,error:"최대 12명까지 플레이할 수 있습니다."});
  r.status="playing";assignRoles(r);log(r,"🎭 모든 플레이어의 역할이 비공개로 배정되었습니다.");sendRoom(r);startNight(r);sendRoom(r);cb?.({ok:true});
 });
 socket.on("nightAction",({action,targetId},cb)=>{
  const r=[...rooms.values()].find(x=>x.players.some(p=>p.id===socket.id));
  if(!r||r.phase!=="night")return cb?.({ok:false,error:"지금은 밤 행동 시간이 아닙니다."});
  const p=r.players.find(x=>x.id===socket.id);
  if(!p?.alive)return cb?.({ok:false,error:"탈락한 플레이어는 행동할 수 없습니다."});
  if(!["mafia","doctor","detective"].includes(action)||p.role!==action)return cb?.({ok:false,error:"이 역할은 해당 행동을 할 수 없습니다."});
  const target=r.players.find(x=>x.id===targetId&&x.alive&&x.id!==p.id);
  if(!target)return cb?.({ok:false,error:"대상을 다시 선택해 주세요."});
  if(action==="mafia"){
   if(target.role==="mafia")return cb?.({ok:false,error:"다른 마피아는 공격할 수 없습니다."});
   r.night.mafia=target.id;
  }else if(action==="doctor")r.night.doctor=target.id;
  else r.night.detectiveResult={playerId:p.id,target:target.name,isMafia:target.role==="mafia"};
  r.night.done.add(action);cb?.({ok:true});maybeFinishNight(r);sendRoom(r);
 });
 socket.on("startVote",(_,cb)=>{
  const r=[...rooms.values()].find(x=>x.hostId===socket.id);
  if(!r||r.phase!=="day")return cb?.({ok:false,error:"지금은 투표를 시작할 수 없습니다."});
  r.phase="vote";r.votes={};log(r,"🗳️ 투표가 시작되었습니다. 각자 비공개로 한 명을 선택하세요.");sendRoom(r);cb?.({ok:true});
 });
 socket.on("castVote",({targetId},cb)=>{
  const r=[...rooms.values()].find(x=>x.players.some(p=>p.id===socket.id));
  if(!r||r.phase!=="vote")return cb?.({ok:false,error:"지금은 투표 시간이 아닙니다."});
  const p=r.players.find(x=>x.id===socket.id);
  if(!p?.alive)return cb?.({ok:false,error:"탈락한 플레이어는 투표할 수 없습니다."});
  if(r.votes[p.id]!==undefined)return cb?.({ok:false,error:"이미 투표했습니다."});
  if(targetId!==null&&!alive(r).some(x=>x.id===targetId&&x.id!==p.id))return cb?.({ok:false,error:"올바른 투표 대상이 아닙니다."});
  r.votes[p.id]=targetId;cb?.({ok:true});
  const voters=alive(r).filter(x=>!x.isAI);
  if(voters.every(x=>r.votes[x.id]!==undefined))resolveVotes(r);
  else sendRoom(r);
 });
 socket.on("disconnect",()=>{
  for(const r of rooms.values()){
   const p=r.players.find(x=>x.id===socket.id);
   if(p){if(r.status==="lobby"){r.players=r.players.filter(x=>x.id!==socket.id);if(r.hostId===socket.id){const next=r.players.find(x=>!x.isAI);r.hostId=next?.id||null}if(!r.players.length)rooms.delete(r.code);else sendRoom(r)}
    else sendRoom(r);
   }
  }
 });
});
server.listen(PORT,()=>console.log(`Night Village running on ${PORT}`));
